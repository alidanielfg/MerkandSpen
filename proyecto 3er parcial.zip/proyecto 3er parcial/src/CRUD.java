/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class CRUD {
    private Connection conexion;
    public CRUD() {
        conexion = ConexionDB.conectar();
    
}

public boolean RegistrarArticulo (String nombre, String descripcion, String cantidad, String categoria ){

        try {
        Integer.parseInt(cantidad);
    } catch (NumberFormatException e) {
        System.out.println("La cantidad debe ser un número válido");
        return false;
    }

    // Primero obtener el ID de la categoría
    int idCategoria;
    String sqlGetCategoria = "SELECT id FROM categorias WHERE nombre = ?";
    
    try (PreparedStatement ps = conexion.prepareStatement(sqlGetCategoria)) {
        ps.setString(1, categoria);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            idCategoria = rs.getInt("id");
        } else {
            // Si la categoría no existe, insertarla
            String sqlInsertCategoria = "INSERT INTO categorias (nombre) VALUES (?)";
            try (PreparedStatement psInsert = conexion.prepareStatement(sqlInsertCategoria, PreparedStatement.RETURN_GENERATED_KEYS)) {
                psInsert.setString(1, categoria);
                psInsert.executeUpdate();
                ResultSet generatedKeys = psInsert.getGeneratedKeys();
                if (generatedKeys.next()) {
                    idCategoria = generatedKeys.getInt(1);
                } else {
                    System.out.println("Error al obtener ID de categoría creada");
                    return false;
                }
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener/insertar categoría: " + e.getMessage());
        return false;
    }

    // Ahora insertar el artículo
    String sqlInsert = "INSERT INTO articulos (nombre, descripcion, cantidad, id_categoria) VALUES (?, ?, ?, ?)";
    try (PreparedStatement ps = conexion.prepareStatement(sqlInsert)) {
        ps.setString(1, nombre);
        ps.setString(2, descripcion);
        ps.setInt(3, Integer.parseInt(cantidad));
        ps.setInt(4, idCategoria);
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("Error al insertar artículo: " + e.getMessage());
        return false;
    }
}

public boolean SolicitarArtinombre(int id_usuario, int id_articulo, String cantidad) {
    try {
        Integer.parseInt(cantidad);
    } catch (NumberFormatException e) {
        System.out.println("La cantidad debe ser un número válido");
        return false;
    }

    // Verificar stock
    String sqlCheckStock = "SELECT cantidad FROM articulos WHERE id = ?";
    try (PreparedStatement ps = conexion.prepareStatement(sqlCheckStock)) {
        ps.setInt(1, id_articulo);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            int stockActual = rs.getInt("cantidad");
            int cantidadSolicitada = Integer.parseInt(cantidad);
            
            if (cantidadSolicitada > stockActual) {
                System.out.println("Stock insuficiente");
                return false;
            }
        } else {
            System.out.println("Artículo no encontrado");
            return false;
        }
    } catch (SQLException e) {
        System.out.println("Error al verificar stock: " + e.getMessage());
        return false;
    }
    
    // Insertar la solicitud
    String sqlInsert = "INSERT INTO solicitudes (id_usuario, id_articulo, cantidad) VALUES (?, ?, ?)";
    try (PreparedStatement ps = conexion.prepareStatement(sqlInsert)) {
        ps.setInt(1, id_usuario);
        ps.setInt(2, id_articulo);
        ps.setInt(3, Integer.parseInt(cantidad));
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        System.out.println("Error al insertar solicitud: " + e.getMessage());
        return false;
    }
}
}








